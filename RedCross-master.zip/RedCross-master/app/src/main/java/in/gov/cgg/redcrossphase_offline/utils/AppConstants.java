package in.gov.cgg.redcrossphase_offline.utils;

public class AppConstants {
    public static final String ERAKTAKOSH_KEY = "b42d8436-f345-4581-95b2-a83fd7bafdd8";
    public static final String STATE_ID = "36";
    public static final String STATE_CODE = "TS";
    public static final String DONORS_OFFLINE = "DONORS_OFFLINE";
    public static final String BB_OFFLINE = "BB_OFFLINE";
    public static final String E_RAKTAKOSH_DATA = "E_RAKTAKOSH_DATA";
    public static final String DONORS_DATA = "DONORS_DATA";
    public static final String FROM_TYPE = "FROM_TYPE";
    public static final String FROM_CLASS = "FROM_CLASS";
    public static final String BLOOD_DONOR = "BLOOD_DONOR";
}
