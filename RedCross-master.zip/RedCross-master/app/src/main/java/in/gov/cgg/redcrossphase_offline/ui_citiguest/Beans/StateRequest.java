package in.gov.cgg.redcrossphase_offline.ui_citiguest.Beans;

public class StateRequest {
    public String stateId;

    public String getStateId() {
        return stateId;
    }

    public void setStateId(String stateId) {
        this.stateId = stateId;
    }
}
