package in.gov.cgg.redcrossphase_offline.ui_citiguest.Beans;

public class CitizenLoginRequest {

    private String mobileNumber;

    public String getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(String mobileNumber) {
        this.mobileNumber = mobileNumber;
    }


}
