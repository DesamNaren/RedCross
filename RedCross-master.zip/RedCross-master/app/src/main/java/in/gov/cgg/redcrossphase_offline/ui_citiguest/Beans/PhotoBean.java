package in.gov.cgg.redcrossphase_offline.ui_citiguest.Beans;

public class PhotoBean {

    String savedFileName;

    public String getSavedFileName() {
        return savedFileName;
    }

    public void setSavedFileName(String savedFileName) {
        this.savedFileName = savedFileName;
    }
}
