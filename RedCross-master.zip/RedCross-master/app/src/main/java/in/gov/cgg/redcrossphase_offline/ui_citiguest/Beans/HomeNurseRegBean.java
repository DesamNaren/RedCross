package in.gov.cgg.redcrossphase_offline.ui_citiguest.Beans;

public class HomeNurseRegBean {
}
