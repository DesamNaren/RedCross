package in.gov.cgg.redcrossphase_offline.retrofit;

public class RequestAll {
    private String districtId;
    private String enrollmentType;
    private String fyId;
    private String userId;


    public String getDistrictId() {
        return districtId;
    }

    public void setDistrictId(String districtId) {
        this.districtId = districtId;
    }

    public String getEnrollmentType() {
        return enrollmentType;
    }

    public void setEnrollmentType(String enrollmentType) {
        this.enrollmentType = enrollmentType;
    }

    public String getFyId() {
        return fyId;
    }

    public void setFyId(String fyId) {
        this.fyId = fyId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
